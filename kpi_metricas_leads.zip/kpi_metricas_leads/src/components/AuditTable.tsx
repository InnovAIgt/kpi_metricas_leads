import React, { useState } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Phone,
  Calendar,
  User,
  Volume2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  FileCheck,
  PhoneForwarded,
  Headphones,
  Download,
  FileText,
} from 'lucide-react';
import { CruceAuditoria, EstadoCumplimiento } from '../types';
import { exportarTablaAExcel, formatearSubtituloExportacion } from '../utils/excelExport';
import { exportarTablaAPdf } from '../utils/pdfExport';
import {
  etiquetaSemaforoCruce,
  obtenerCanalLlamadaLabel,
} from '../utils/kpiExcelBuilder';
import { formatLocalDate } from '../utils/dateHelpers';
import { claseBadgeHorarioIngreso } from './SemaforoCumplimiento';
import { clasificarHorarioIngreso, obtenerTimestampCreacionLead } from '../utils/matchingEngine';

interface AuditTableProps {
  cruces: CruceAuditoria[];
  onAuditarCruce?: (cruceId: string, notas: string) => void;
  onVerTranscripcion?: (llamada: any) => void;
}

export const AuditTable: React.FC<AuditTableProps> = ({
  cruces,
  onAuditarCruce,
  onVerTranscripcion,
}) => {
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState<string>('todos');
  const [filtroVendedor, setFiltroVendedor] = useState<string>('todos');
  const [cruceExpandido, setCruceExpandido] = useState<string | null>(null);
  const [notasSupervisor, setNotasSupervisor] = useState<{ [id: string]: string }>({});
  const [reproduciendoAudio, setReproduciendoAudio] = useState<string | null>(null);
  const [exportando, setExportando] = useState(false);
  const [exportandoPdf, setExportandoPdf] = useState(false);

  const construirHojaCruces = () => ({
    name: 'Cruces Auditoría',
    title: 'Detalle de Cruces de Auditoría KPI',
    subtitle: formatearSubtituloExportacion({
      totalFilas: crucesFiltrados.length,
      modo: 'Cruces Filtrados',
    }),
    accentHex: '1E293B',
    columns: [
      {
        header: 'Semáforo',
        key: 'estado_cumplimiento',
        width: 22,
        value: (c: CruceAuditoria) => etiquetaSemaforoCruce(c.estado_cumplimiento).etiquetaSemaforo,
        semantic: 'semaforo' as const,
        align: 'center' as const,
      },
      { header: 'Prospecto', key: 'prospecto_nombre', width: 26 },
      { header: 'Teléfono', key: 'telefono', width: 16 },
      { header: 'Vendedor', key: 'vendedor_nombre', width: 24 },
      { header: 'Cita Programada', key: 'fecha_cita', value: (c: CruceAuditoria) => (c.fecha_cita ? c.fecha_cita.replace('T', ' ').slice(0, 16) : '-'), align: 'center' as const },
      { header: 'Llamada Real', key: 'fecha_llamada', value: (c: CruceAuditoria) => (c.fecha_llamada ? c.fecha_llamada.replace('T', ' ').slice(0, 16) : 'Sin registro'), align: 'center' as const },
      { header: 'Canal de Llamada', key: 'canal_utilizado', width: 16, value: (c: CruceAuditoria) => obtenerCanalLlamadaLabel(c), align: 'center' as const },
      { header: 'Duración', key: 'duracion_llamada_segundos', value: (c: CruceAuditoria) => formatearSegundos(c.duracion_llamada_segundos), align: 'center' as const },
      { header: 'Desfase (min)', key: 'desfase_minutos', value: (c: CruceAuditoria) => c.desfase_minutos ?? '-', align: 'right' as const },
      {
        header: 'Horario Ingreso',
        key: 'horario_ingreso_tipo',
        width: 22,
        value: (c: CruceAuditoria) =>
          c.horario_ingreso_tipo || clasificarHorarioIngreso(obtenerTimestampCreacionLead(c.cita)),
        semantic: 'status' as const,
        align: 'center' as const,
      },
      { header: 'Diagnóstico', key: 'explicacion', width: 42, wrapText: true },
    ],
    rows: crucesFiltrados,
  });

  // Lista única de vendedores para el selector
  const listaVendedores = Array.from(new Set(cruces.map((c) => c.vendedor_nombre))).filter(Boolean);

  // Filtrado reactivo
  const crucesFiltrados = cruces.filter((c) => {
    const matchBusqueda =
      c.prospecto_nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      c.telefono.toLowerCase().includes(busqueda.toLowerCase()) ||
      c.vendedor_nombre.toLowerCase().includes(busqueda.toLowerCase());

    const matchEstado =
      filtroEstado === 'todos'
        ? true
        : filtroEstado === 'TARDE_LEVE'
        ? c.estado_cumplimiento === 'TARDE_LEVE' || c.estado_cumplimiento === 'LLAMADA_CORTA'
        : c.estado_cumplimiento === filtroEstado;

    const matchVendedor =
      filtroVendedor === 'todos' ? true : c.vendedor_nombre === filtroVendedor;

    return matchBusqueda && matchEstado && matchVendedor;
  });

  const formatearFechaHora = (iso?: string) => {
    if (!iso) return '-';
    const d = new Date(iso);
    return d.toLocaleString('es-ES', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatearSegundos = (seg?: number) => {
    if (seg === undefined || seg === null) return '-';
    const min = Math.floor(seg / 60);
    const resto = seg % 60;
    return `${min}m ${resto}s`;
  };

  const badgeEstado = (estado: EstadoCumplimiento, desfase?: number) => {
    switch (estado) {
      case 'A_TIEMPO':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-300 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30">
            <CheckCircle2 className="h-3.5 w-3.5" />
            A Tiempo {desfase !== undefined ? `(${desfase > 0 ? `+${desfase}m` : `${desfase}m`})` : ''}
          </span>
        );
      case 'TARDE_LEVE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30">
            <AlertTriangle className="h-3.5 w-3.5" />
            Tarde Leve {desfase !== undefined ? `(+${desfase}m)` : ''}
          </span>
        );
      case 'TARDE_GRAVE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-300 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30">
            <AlertTriangle className="h-3.5 w-3.5" />
            Tarde Grave {desfase !== undefined ? `(+${desfase}m)` : ''}
          </span>
        );
      case 'NO_LLAMO':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-300 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800">
            <XCircle className="h-3.5 w-3.5" />
            No Llamó
          </span>
        );
      case 'LLAMADA_CORTA':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-300 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30">
            <Clock className="h-3.5 w-3.5" />
            Tarde Leve (Corta)
          </span>
        );
      case 'LLAMO_OTRO_DIA':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-300 dark:bg-indigo-500/15 dark:text-indigo-300 dark:border-indigo-500/30">
            <Calendar className="h-3.5 w-3.5" />
            Otro Día
          </span>
        );
      case 'PENDIENTE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700">
            <Clock className="h-3.5 w-3.5" />
            Pendiente
          </span>
        );
      case 'ADELANTADA':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-300 dark:bg-blue-500/15 dark:text-blue-300 dark:border-blue-500/30">
            <Clock className="h-3.5 w-3.5" />
            Adelantada ({desfase}m)
          </span>
        );
      case 'SIN_CITA':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-300 dark:bg-purple-500/15 dark:text-purple-300 dark:border-purple-500/30">
            <PhoneForwarded className="h-3.5 w-3.5" />
            Sin Cita Previa
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Search & Filter Header Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs dark:shadow-none space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          {/* Search Box */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              placeholder="Buscar por prospecto, teléfono o vendedor..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors shadow-xs"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            {/* Vendedor Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-300">
              <User className="h-3.5 w-3.5 text-slate-400" />
              <select
                value={filtroVendedor}
                onChange={(e) => setFiltroVendedor(e.target.value)}
                className="bg-transparent border-none text-xs text-slate-900 dark:text-white focus:outline-none cursor-pointer"
              >
                <option value="todos" className="bg-white dark:bg-slate-900">
                  Todos los Vendedores
                </option>
                {listaVendedores.map((v) => (
                  <option key={v} value={v} className="bg-white dark:bg-slate-900">
                    {v}
                  </option>
                ))}
              </select>
            </div>

            {/* Estado Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-300">
              <Filter className="h-3.5 w-3.5 text-slate-400" />
              <select
                value={filtroEstado}
                onChange={(e) => setFiltroEstado(e.target.value)}
                className="bg-transparent border-none text-xs text-slate-900 dark:text-white focus:outline-none cursor-pointer"
              >
                <option value="todos" className="bg-white dark:bg-slate-900">
                  Todos los Estados ({cruces.length})
                </option>
                <option value="A_TIEMPO" className="bg-white dark:bg-slate-900">
                  A Tiempo (Verde)
                </option>
                <option value="TARDE_LEVE" className="bg-white dark:bg-slate-900">
                  Tarde Leve (Amarillo)
                </option>
                <option value="TARDE_GRAVE" className="bg-white dark:bg-slate-900">
                  Tarde Grave (Rojo)
                </option>
                <option value="NO_LLAMO" className="bg-white dark:bg-slate-900">
                  No Llamó
                </option>
                <option value="LLAMO_OTRO_DIA" className="bg-white dark:bg-slate-900">
                  Otro Día
                </option>
                <option value="ADELANTADA" className="bg-white dark:bg-slate-900">
                  Adelantada
                </option>
                <option value="PENDIENTE" className="bg-white dark:bg-slate-900">
                  Pendiente
                </option>
                <option value="SIN_CITA" className="bg-white dark:bg-slate-900">
                  Sin Cita Previa
                </option>
              </select>
            </div>

            <span className="text-xs text-slate-500 dark:text-slate-400 ml-auto tabular-nums">
              Mostrando <strong className="text-slate-900 dark:text-white">{crucesFiltrados.length}</strong> registros
            </span>

            <button
              type="button"
              onClick={async () => {
                setExportando(true);
                try {
                  await exportarTablaAExcel(`Detalle_Cruces_${formatLocalDate()}`, construirHojaCruces());
                } finally {
                  setExportando(false);
                }
              }}
              disabled={exportando || crucesFiltrados.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer disabled:opacity-50"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{exportando ? 'Exportando...' : 'Descargar Excel'}</span>
            </button>

            <button
              type="button"
              onClick={async () => {
                setExportandoPdf(true);
                try {
                  await exportarTablaAPdf(`Detalle_Cruces_${formatLocalDate()}`, construirHojaCruces());
                } finally {
                  setExportandoPdf(false);
                }
              }}
              disabled={exportandoPdf || crucesFiltrados.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer disabled:opacity-50"
            >
              <FileText className="h-3.5 w-3.5" />
              <span>{exportandoPdf ? 'PDF...' : 'Descargar PDF'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs dark:shadow-none">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300 tabular-nums">
            <thead className="bg-slate-50 dark:bg-slate-950/80 text-slate-600 dark:text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3 font-semibold">Prospecto / Contacto</th>
                <th className="px-4 py-3 font-semibold">Vendedor / Closer</th>
                <th className="px-4 py-3 font-semibold">Horario Ingreso</th>
                <th className="px-4 py-3 font-semibold">Cita Programada</th>
                <th className="px-4 py-3 font-semibold">Llamada Real</th>
                <th className="px-4 py-3 font-semibold">Duración</th>
                <th className="px-4 py-3 font-semibold">Cumplimiento KPI</th>
                <th className="px-4 py-3 text-right font-semibold">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
              {crucesFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-10 text-slate-500 dark:text-slate-400">
                    No se encontraron registros de cruce con los filtros seleccionados.
                  </td>
                </tr>
              ) : (
                crucesFiltrados.map((item) => {
                  const estaExpandido = cruceExpandido === item.id;
                  return (
                    <React.Fragment key={item.id}>
                      <tr
                        className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors cursor-pointer ${
                          estaExpandido ? 'bg-slate-50/80 dark:bg-slate-800/30' : ''
                        }`}
                        onClick={() => setCruceExpandido(estaExpandido ? null : item.id)}
                      >
                        {/* Prospecto */}
                        <td className="px-4 py-3.5">
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white block">
                              {item.prospecto_nombre}
                            </span>
                            <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                              {item.telefono}
                            </span>
                            {item.cita?.fuente && (
                              <span className="inline-block text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 ml-1.5 font-sans font-medium">
                                {item.cita.fuente}
                              </span>
                            )}
                          </div>
                        </td>

                        {/* Vendedor */}
                        <td className="px-4 py-3.5">
                          <span className="text-slate-800 dark:text-slate-200 font-medium">{item.vendedor_nombre}</span>
                        </td>

                        {/* Horario Ingreso */}
                        <td className="px-4 py-3.5 whitespace-nowrap">
                          {(() => {
                            const hTipo =
                              item.horario_ingreso_tipo ||
                              clasificarHorarioIngreso(obtenerTimestampCreacionLead(item.cita));
                            return (
                              <span
                                className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold border ${claseBadgeHorarioIngreso(hTipo)}`}
                              >
                                {hTipo}
                              </span>
                            );
                          })()}
                        </td>

                        {/* Hora Cita */}
                        <td className="px-4 py-3.5 font-mono">
                          {item.fecha_cita ? (
                            <span className="text-slate-700 dark:text-slate-200">
                              {formatearFechaHora(item.fecha_cita)}
                            </span>
                          ) : (
                            <span className="text-slate-400 dark:text-slate-500 italic">Sin Cita</span>
                          )}
                        </td>

                        {/* Hora Llamada */}
                        <td className="px-4 py-3.5 font-mono">
                          {item.fecha_llamada ? (
                            <span className="text-slate-700 dark:text-slate-200">
                              {formatearFechaHora(item.fecha_llamada)}
                            </span>
                          ) : (
                            <span className="text-rose-600 dark:text-rose-400 font-semibold italic">
                              No registrada
                            </span>
                          )}
                        </td>

                        {/* Duración */}
                        <td className="px-4 py-3.5">
                          <span
                            className={`${
                              item.duracion_llamada_segundos && item.duracion_llamada_segundos < 60
                                ? 'text-amber-600 dark:text-amber-400 font-medium'
                                : 'text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {formatearSegundos(item.duracion_llamada_segundos)}
                          </span>
                        </td>

                        {/* Estado Cumplimiento */}
                        <td className="px-4 py-3.5">
                          {badgeEstado(item.estado_cumplimiento, item.desfase_minutos)}
                        </td>

                        {/* Acción / Toggle */}
                        <td className="px-4 py-3.5 text-right">
                          <button
                            type="button"
                            className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-white"
                          >
                            {estaExpandido ? (
                              <ChevronUp className="h-4 w-4" />
                            ) : (
                              <ChevronDown className="h-4 w-4" />
                            )}
                          </button>
                        </td>
                      </tr>

                      {/* Expandable Audit Details Row */}
                      {estaExpandido && (
                        <tr className="bg-slate-50/80 dark:bg-slate-950/60 border-b border-slate-200 dark:border-slate-800">
                          <td colSpan={8} className="p-4">
                            <div className="rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 space-y-3 shadow-xs">
                              <div className="flex flex-col md:flex-row justify-between gap-4 border-b border-slate-200 dark:border-slate-800/80 pb-3">
                                <div>
                                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                                    <FileCheck className="h-4 w-4 text-indigo-500 dark:text-indigo-400" />
                                    Diagnóstico del Cruce de Auditoría
                                  </h4>
                                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">{item.explicacion}</p>
                                </div>
                                <div className="flex items-center gap-3">
                                  {onVerTranscripcion && (item.fecha_llamada || item.llamada) && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        onVerTranscripcion(
                                          item.llamada
                                            ? item.llamada
                                            : {
                                                uniqueid: item.id,
                                                destino: item.telefono,
                                                nombre: item.vendedor_nombre,
                                                fecha_hora: item.fecha_llamada,
                                                duracion_segundos: item.duracion_llamada_segundos,
                                                estado: 'CONTESTADA',
                                              }
                                        );
                                      }}
                                      className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm shadow-indigo-600/30 cursor-pointer font-bold transition-all"
                                      title="Escuchar audio y leer la transcripción en la misma ventana"
                                    >
                                      <Headphones className="h-3.5 w-3.5 shrink-0" />
                                      <span>Consultar Llamada</span>
                                    </button>
                                  )}
                                  {item.llamada?.grabacion_url && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setReproduciendoAudio(
                                          reproduciendoAudio === item.id ? null : item.id
                                        );
                                      }}
                                      className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 dark:bg-indigo-600/20 dark:text-indigo-300 dark:border-indigo-500/30 dark:hover:bg-indigo-600/30 cursor-pointer transition-colors shadow-xs"
                                    >
                                      <Volume2 className="h-3.5 w-3.5" />
                                      <span>
                                        {reproduciendoAudio === item.id
                                          ? 'Pausar Audio'
                                          : 'Escuchar Grabación'}
                                      </span>
                                    </button>
                                  )}
                                  {item.cita?.valor_estimado && (
                                    <div className="text-xs text-slate-500 dark:text-slate-400">
                                      Valor estimado:{' '}
                                      <strong className="text-emerald-600 dark:text-emerald-400">
                                        ${item.cita.valor_estimado.toLocaleString()} USD
                                      </strong>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Simulated audio player player bar */}
                              {reproduciendoAudio === item.id && (
                                <div className="p-2.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/40 flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                                    <span className="text-xs text-indigo-800 dark:text-indigo-200">
                                      Reproduciendo audio de llamada ({item.llamada?.proveedor}): 0:14 /{' '}
                                      {formatearSegundos(item.duracion_llamada_segundos)}
                                    </span>
                                  </div>
                                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                                    128 kbps stereo
                                  </span>
                                </div>
                              )}

                              {/* Context Notes & Supervisor Section */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                                <div>
                                  <span className="text-slate-600 dark:text-slate-400 block font-semibold mb-1">
                                    Detalles de la Cita (CRM / Calendario):
                                  </span>
                                  <div className="bg-slate-50 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800/80 text-slate-700 dark:text-slate-300 space-y-1">
                                    <p>
                                      <strong>Tipo:</strong>{' '}
                                      {item.cita?.tipo_reunion || 'No especificado'}
                                    </p>
                                    <p>
                                      <strong>Email:</strong>{' '}
                                      {item.cita?.prospecto_email || 'Sin correo'}
                                    </p>
                                    <p>
                                      <strong>Notas previas:</strong>{' '}
                                      {item.cita?.notas || 'Sin comentarios registrados.'}
                                    </p>
                                  </div>
                                </div>

                                <div>
                                  <span className="text-slate-600 dark:text-slate-400 block font-semibold mb-1">
                                    Notas del Vendedor / Telefonía ({item.llamada?.proveedor || 'Sin telefonía'}):
                                  </span>
                                  <div className="bg-slate-50 dark:bg-slate-950 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800/80 text-slate-700 dark:text-slate-300 space-y-1">
                                    <p>
                                      <strong>Resultado reportado:</strong>{' '}
                                      {item.llamada?.resultado || 'No hubo llamada'}
                                    </p>
                                    <p>
                                      <strong>Comentario de la llamada:</strong>{' '}
                                      {item.llamada?.notas_llamada || 'Sin notas en telefonía.'}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
