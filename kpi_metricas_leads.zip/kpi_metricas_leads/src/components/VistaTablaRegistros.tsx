import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Calendar,
  X,
  Play,
  ExternalLink,
  PhoneCall,
  Smartphone,
  MessageSquare,
  Zap,
  Users,
  Edit,
  Plus,
  Check,
  AlertCircle,
  FileText,
  RefreshCw,
} from 'lucide-react';
import { ColumnFilterDropdown } from './ColumnFilterDropdown';
import { DateRangeFilter } from './DateRangeFilter';
import {
  getRangoDefaultLeads,
  getMesActualInfo,
  getMesAnteriorInfo,
  formatLocalDate,
} from '../utils/dateHelpers';
import {
  exportarTablaAExcel,
  formatearSubtituloExportacion,
  ExcelColumn,
} from '../utils/excelExport';
import { exportarTablaAPdf } from '../utils/pdfExport';
import { formatearPaisAlcance } from '../utils/kpiExcelBuilder';

export interface ColumnaDef {
  clave: string;
  etiqueta: string;
  grupo?: string;
  esFecha?: boolean;
  render?: (val: any, fila: any) => React.ReactNode;
  exportValue?: (val: any, fila: any) => string | number | boolean | null | undefined;
}

interface VistaTablaRegistrosProps {
  titulo: string;
  subtitulo: string;
  icono: 'pbx' | 'celular' | 'whatsapp' | 'leads' | 'teams';
  datos: any[];
  columnas: ColumnaDef[];
  catalogo?: any[];
  onGuardarTeams?: (reunion: any) => Promise<boolean>;
  onGuardarLlamadaManual?: (tipo: 'pbx' | 'celular', datos: any) => Promise<boolean>;
  leadsDisponibles?: any[];
  ocultarFiltroReunion?: boolean;
  onSincronizarProspektia?: () => void;
  sincronizandoProspektia?: boolean;
}

function extraerFechaSvLocal(valor?: any): string {
  if (!valor || valor === 'null') return '';
  const raw = String(valor).trim();
  if (!raw) return '';
  if (/(Z|[+-]\d{2}:?\d{2})$/i.test(raw)) {
    const d = new Date(raw);
    if (!isNaN(d.getTime())) {
      const sv = new Date(d.getTime() - 6 * 3600 * 1000);
      return sv.toISOString().slice(0, 10);
    }
  }
  const m = raw.match(/^(\d{4}-\d{2}-\d{2})/);
  return m ? m[1] : '';
}

export const VistaTablaRegistros: React.FC<VistaTablaRegistrosProps> = ({
  titulo,
  subtitulo,
  icono,
  datos,
  columnas,
  catalogo = [],
  onGuardarTeams,
  onGuardarLlamadaManual,
  leadsDisponibles = [],
  ocultarFiltroReunion = false,
  onSincronizarProspektia,
  sincronizandoProspektia = false,
}) => {
  const [busqueda, setBusqueda] = useState('');
  const [exportando, setExportando] = useState(false);
  const [exportandoPdf, setExportandoPdf] = useState(false);
  const [fechaInicio, setFechaInicio] = useState(() => getRangoDefaultLeads().inicio);
  const [fechaFin, setFechaFin] = useState(() => getRangoDefaultLeads().fin);

  // Estado para modal de Teams (Ingresar/Editar llamada)
  const [modalTeamsAbierto, setModalTeamsAbierto] = useState(false);
  const [editingTeamsItem, setEditingTeamsItem] = useState<any | null>(null);
  const [guardandoTeams, setGuardandoTeams] = useState(false);

  // Estado para modal de Llamada Manual (PBX y Celular)
  const [modalLlamadaManualAbierto, setModalLlamadaManualAbierto] = useState(false);
  const [guardandoLlamadaManual, setGuardandoLlamadaManual] = useState(false);
  const [filtroLeadModal, setFiltroLeadModal] = useState('');
  const [formLlamadaManual, setFormLlamadaManual] = useState({
    codigo_lead: '',
    prospecto_nombre: '',
    telefono_destino: '',
    ejecutivo: '',
    extension: '',
    fecha: formatLocalDate(),
    hora: '10:00:00',
    duracion_segundos: 180,
    estado: 'CONTESTADA',
    pais: 'SV',
  });

  // Filtros dinámicos por cada columna: { [claveColumna]: string[] (valores marcados) }
  const [filtrosColumnas, setFiltrosColumnas] = useState<Record<string, string[]>>({});
  const [paisFiltroRapido, setPaisFiltroRapido] = useState<'TODOS' | 'SV' | 'GT'>('TODOS');

  // Para leads calificados: permitir filtrar opcionalmente solo los que tienen reunión agendada pactada
  const [soloConReunion, setSoloConReunion] = useState(false);

  const tieneColumnaPais = useMemo(
    () => columnas.some((c) => c.clave === 'pais'),
    [columnas]
  );

  // Al cambiar de tabla (ej. Calificados <-> No Calificados <-> PBX/Celular), limpiar filtros de columnas previos
  React.useEffect(() => {
    setFiltrosColumnas({});
    setSoloConReunion(false);
    setPaisFiltroRapido('TODOS');
  }, [titulo, icono]);

  const handleCambiarFiltroColumna = (clave: string, seleccionados: string[]) => {
    setFiltrosColumnas((prev) => ({
      ...prev,
      [clave]: seleccionados,
    }));
  };

  const abrirModalTeamsNuevo = () => {
    setEditingTeamsItem({
      codigo_prospecto: '',
      cliente: '',
      ejecutivo: catalogo[0]?.nombre_ejecutivo || '',
      pais: 'SV',
      fecha_reunion: formatLocalDate(),
      hora_reunion: '10:00',
      estado_teams: 'Si se hizo y tiene evidencia',
      evidencia_url: '',
      notas: '',
    });
    setModalTeamsAbierto(true);
  };

  const abrirModalTeamsEditar = (fila: any) => {
    setEditingTeamsItem({
      id: fila.id,
      codigo_prospecto: fila.codigo_prospecto || '',
      cliente: fila.cliente || fila.nombre_prospecto || '',
      ejecutivo: fila.ejecutivo_nombre || fila.ejecutivo || '',
      pais: fila.pais || 'SV',
      fecha_reunion: fila.fecha_reunion || (fila.fecha_agendada ? String(fila.fecha_agendada).slice(0, 10) : formatLocalDate()),
      hora_reunion: fila.hora_reunion || (fila.hora_agendada ? String(fila.hora_agendada).slice(0, 5) : '10:00'),
      estado_teams: fila.estado_teams || 'Si se hizo y tiene evidencia',
      evidencia_url: fila.evidencia_url || '',
      notas: fila.notas || '',
    });
    setModalTeamsAbierto(true);
  };

  const handleGuardarTeamsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTeamsItem || !onGuardarTeams) return;
    setGuardandoTeams(true);
    try {
      const ok = await onGuardarTeams(editingTeamsItem);
      if (ok) {
        setModalTeamsAbierto(false);
        setEditingTeamsItem(null);
      }
    } finally {
      setGuardandoTeams(false);
    }
  };

  const abrirModalLlamadaManual = () => {
    const primerCat = catalogo[0];
    const primerLead = leadsDisponibles[0];
    const fLead = primerLead?.fecha_agendada || (primerLead?.fecha_creado ? String(primerLead.fecha_creado).slice(0, 10) : formatLocalDate());
    let hLead = primerLead?.hora_agendada || primerLead?.hora_creado || '10:00:00';
    if (hLead.length === 5) hLead += ':00';

    setFormLlamadaManual({
      codigo_lead: primerLead?.codigo_prospecto || primerLead?.id || '',
      prospecto_nombre: primerLead?.nombre_prospecto || primerLead?.nombre || primerLead?.cliente || '',
      telefono_destino: String(primerLead?.telefono || primerLead?.celular || '').trim(),
      ejecutivo: primerLead?.asesor_nombre || primerCat?.nombre_ejecutivo || 'LCANAS',
      extension: primerCat?.extension || '4031',
      fecha: fLead,
      hora: hLead,
      duracion_segundos: 180,
      estado: 'CONTESTADA',
      pais: primerLead?.pais || 'SV',
    });
    setFiltroLeadModal('');
    setModalLlamadaManualAbierto(true);
  };

  const handleSeleccionarLead = (leadCodOrId: string) => {
    const lead = leadsDisponibles.find(
      (l) => String(l.codigo_prospecto || l.id) === String(leadCodOrId)
    );
    if (!lead) return;
    const fLead = lead.fecha_agendada || (lead.fecha_creado ? String(lead.fecha_creado).slice(0, 10) : formatLocalDate());
    let hLead = lead.hora_agendada || lead.hora_creado || '10:00:00';
    if (hLead.length === 5) hLead += ':00';

    const catItem = catalogo.find(
      (c: any) =>
        String(c.nombre_ejecutivo || '').toLowerCase() === String(lead.asesor_nombre || '').toLowerCase()
    );

    setFormLlamadaManual((prev) => ({
      ...prev,
      codigo_lead: lead.codigo_prospecto || lead.id,
      prospecto_nombre: lead.nombre_prospecto || lead.nombre || lead.cliente || '',
      telefono_destino: String(lead.telefono || lead.celular || '').trim(),
      ejecutivo: lead.asesor_nombre || prev.ejecutivo,
      extension: catItem?.extension || prev.extension,
      fecha: fLead,
      hora: hLead,
      pais: lead.pais || 'SV',
    }));
  };

  const handleSeleccionarEjecutivo = (ejecutivoNombre: string) => {
    const catItem = catalogo.find(
      (c: any) => String(c.nombre_ejecutivo || '').toLowerCase() === ejecutivoNombre.toLowerCase()
    );
    // Buscar si el ejecutivo tiene leads asignados
    const leadDelAsesor = leadsDisponibles.find((l) => {
      const nomAsesor = String(l.asesor_nombre || '').toLowerCase();
      const nomCat = String(catItem?.nombre_ejecutivo || ejecutivoNombre).toLowerCase();
      return nomAsesor.includes(nomCat) || nomCat.includes(nomAsesor);
    });

    if (leadDelAsesor) {
      const fLead =
        leadDelAsesor.fecha_agendada ||
        (leadDelAsesor.fecha_creado
          ? String(leadDelAsesor.fecha_creado).slice(0, 10)
          : formatLocalDate());
      let hLead = leadDelAsesor.hora_agendada || leadDelAsesor.hora_creado || '10:00:00';
      if (hLead.length === 5) hLead += ':00';

      setFormLlamadaManual((prev) => ({
        ...prev,
        ejecutivo: ejecutivoNombre,
        extension: catItem?.extension || prev.extension,
        codigo_lead: leadDelAsesor.codigo_prospecto || leadDelAsesor.id,
        prospecto_nombre:
          leadDelAsesor.nombre_prospecto ||
          leadDelAsesor.nombre ||
          leadDelAsesor.cliente ||
          '',
        telefono_destino: String(
          leadDelAsesor.telefono || leadDelAsesor.celular || ''
        ).trim(),
        fecha: fLead,
        hora: hLead,
        pais: leadDelAsesor.pais || prev.pais,
      }));
    } else {
      setFormLlamadaManual((prev) => ({
        ...prev,
        ejecutivo: ejecutivoNombre,
        extension: catItem?.extension || prev.extension,
      }));
    }
  };

  const handleGuardarLlamadaManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onGuardarLlamadaManual) return;
    setGuardandoLlamadaManual(true);
    try {
      const ok = await onGuardarLlamadaManual(icono === 'pbx' ? 'pbx' : 'celular', formLlamadaManual);
      if (ok) {
        setModalLlamadaManualAbierto(false);
      }
    } finally {
      setGuardandoLlamadaManual(false);
    }
  };

  const renderIcono = () => {
    switch (icono) {
      case 'pbx':
        return <PhoneCall className="h-5 w-5 text-red-400" />;
      case 'celular':
        return <Smartphone className="h-5 w-5 text-blue-400" />;
      case 'whatsapp':
        return <MessageSquare className="h-5 w-5 text-emerald-400" />;
      case 'leads':
        return <Zap className="h-5 w-5 text-amber-400" />;
      case 'teams':
        return <Users className="h-5 w-5 text-purple-400" />;
    }
  };

  // 1. Filtrado por país rápido, solo reuniones agendadas y fechas (sin desfase UTC)
  const datosConFecha = useMemo(() => {
    let base = datos;

    if (tieneColumnaPais && paisFiltroRapido !== 'TODOS') {
      base = base.filter(
        (fila) => String(fila.pais || 'SV').toUpperCase() === paisFiltroRapido
      );
    }

    // Solo aplica a Leads Calificados cuando no está oculto
    if (icono === 'leads' && !ocultarFiltroReunion && soloConReunion) {
      base = base.filter(
        (fila) =>
          fila.fecha_agendada &&
          String(fila.fecha_agendada).trim() !== '' &&
          fila.fecha_agendada !== 'null'
      );
    }

    if (!fechaInicio && !fechaFin) return base;

    if (icono === 'leads') {
      return base.filter((fila) => {
        const fechas = ocultarFiltroReunion
          ? [
              extraerFechaSvLocal(fila.fecha) ||
                extraerFechaSvLocal(fila.created_at),
            ].filter(Boolean)
          : [
              extraerFechaSvLocal(fila.fecha_agendada),
              extraerFechaSvLocal(fila.fecha_creado),
              extraerFechaSvLocal(fila.created_at),
              extraerFechaSvLocal(fila.fecha),
            ].filter(Boolean);

        if (fechas.length === 0) return true;
        return fechas.some((f) => {
          if (fechaInicio && f < fechaInicio) return false;
          if (fechaFin && f > fechaFin) return false;
          return true;
        });
      });
    }

    // Para llamadas y otros registros: detectar columna de fecha en la tabla
    const colFecha = columnas.find((c) =>
      c.esFecha ||
      c.clave.includes('fecha') ||
      c.clave.includes('created_at') ||
      c.clave.includes('hora')
    )?.clave;

    return base.filter((fila) => {
      let valor = colFecha ? fila[colFecha] : null;
      if (!valor) {
        valor =
          fila.fecha_agendada ||
          fila.fecha_creado ||
          fila.created_at ||
          fila.fecha;
      }
      if (!valor) return true;
      const strFecha = extraerFechaSvLocal(valor) || String(valor).slice(0, 10);
      if (fechaInicio && strFecha < fechaInicio) return false;
      if (fechaFin && strFecha > fechaFin) return false;
      return true;
    });
  }, [
    datos,
    fechaInicio,
    fechaFin,
    columnas,
    icono,
    soloConReunion,
    ocultarFiltroReunion,
    tieneColumnaPais,
    paisFiltroRapido,
  ]);

  const obtenerValorColumna = (col: ColumnaDef, fila: any): string => {
    if (col.clave === 'consultar' && !col.exportValue) {
      const dur = Number(fila.duracion_segundos || fila.duracion || 0);
      const est = String(fila.estado || '').toUpperCase();
      const noCont =
        est.includes('NO CONTESTADA') ||
        est.includes('OCUPADA') ||
        est.includes('FALLIDA') ||
        dur === 0;
      return noCont ? 'Sin voz (0s)' : 'Disponible';
    }
    const raw = col.exportValue ? col.exportValue(fila[col.clave], fila) : fila[col.clave];
    if (typeof raw === 'boolean') return raw ? 'Sí' : 'No';
    if (raw === undefined || raw === null) return '';
    return String(raw).trim();
  };

  // 2. Extraer valores únicos por cada columna para el checklist (usando el valor visible real)
  const valoresUnicosPorColumna = useMemo(() => {
    const mapa: Record<string, string[]> = {};
    columnas.forEach((col) => {
      const setVal = new Set<string>();
      datosConFecha.forEach((fila) => {
        setVal.add(obtenerValorColumna(col, fila));
      });
      mapa[col.clave] = Array.from(setVal).sort((a, b) =>
        a.localeCompare(b, 'es', { sensitivity: 'base' })
      );
    });
    return mapa;
  }, [datosConFecha, columnas]);

  // 3. Filtrado completo por buscador global y checklist de columnas
  const filtrados = useMemo(() => {
    let resultado = datosConFecha;

    // A. Buscador global (busca tanto en campos crudos como en valores visibles)
    if (busqueda.trim()) {
      const q = busqueda.toLowerCase().trim();
      resultado = resultado.filter(
        (fila) =>
          Object.values(fila).some(
            (val) => val !== null && val !== undefined && String(val).toLowerCase().includes(q)
          ) ||
          columnas.some((col) => obtenerValorColumna(col, fila).toLowerCase().includes(q))
      );
    }

    // B. Filtros individuales por cada columna
    Object.entries(filtrosColumnas).forEach(([clave, seleccionados]) => {
      if (seleccionados.length === 0) return; // todos permitidos
      const activos = seleccionados.filter((s) => s !== '__NINGUNO__');
      if (activos.length === 0) {
        resultado = [];
        return;
      }

      const colDef = columnas.find((c) => c.clave === clave);
      resultado = resultado.filter((fila) => {
        const strValor = colDef
          ? obtenerValorColumna(colDef, fila)
          : typeof fila[clave] === 'boolean'
          ? fila[clave]
            ? 'Sí'
            : 'No'
          : String(fila[clave] ?? '').trim();
        return activos.includes(strValor);
      });
    });

    // Ordenar descendente por fecha para que los registros más recientes aparezcan siempre de primero
    const colFecha = columnas.find((c) =>
      c.esFecha ||
      c.clave.includes('fecha') ||
      c.clave.includes('created_at') ||
      c.clave.includes('calldate')
    )?.clave;

    return [...resultado].sort((a, b) => {
      const valA =
        a.fecha && a.hora
          ? `${a.fecha}T${a.hora}`
          : (colFecha ? a[colFecha] : null) ||
            a.fecha_agendada ||
            a.fecha_hora ||
            a.fecha_llamada ||
            a.fecha ||
            a.created_at ||
            '';
      const valB =
        b.fecha && b.hora
          ? `${b.fecha}T${b.hora}`
          : (colFecha ? b[colFecha] : null) ||
            b.fecha_agendada ||
            b.fecha_hora ||
            b.fecha_llamada ||
            b.fecha ||
            b.created_at ||
            '';
      return String(valB).localeCompare(String(valA));
    });
  }, [datosConFecha, busqueda, filtrosColumnas, columnas]);

  // Paginación optimizada para ultra velocidad (renderiza en <2ms)
  const [paginaActual, setPaginaActual] = useState(1);
  const [filasPorPagina, setFilasPorPagina] = useState(100);

  // Reiniciar a página 1 al cambiar filtros o búsqueda
  React.useEffect(() => {
    setPaginaActual(1);
  }, [busqueda, fechaInicio, fechaFin, filtrosColumnas, paisFiltroRapido, soloConReunion, datos]);

  const totalPaginas = Math.max(1, Math.ceil(filtrados.length / filasPorPagina));
  const filasPaginadas = useMemo(() => {
    const inicio = (paginaActual - 1) * filasPorPagina;
    return filtrados.slice(inicio, inicio + filasPorPagina);
  }, [filtrados, paginaActual, filasPorPagina]);

  // Agrupamiento de columnas (ej: KPI RETROALIMENTACION / KPI SLA)
  const hayGrupos = useMemo(() => columnas.some((c) => Boolean(c.grupo)), [columnas]);

  const headerEstructura = useMemo(() => {
    if (!hayGrupos) return { row1: [], row2: [] };

    type ItemRow1 =
      | { type: 'single'; col: ColumnaDef; index: number }
      | { type: 'group'; grupo: string; colSpan: number; index: number };

    const row1: ItemRow1[] = [];
    let i = 0;
    while (i < columnas.length) {
      const col = columnas[i];
      if (!col.grupo) {
        row1.push({ type: 'single', col, index: i });
        i++;
      } else {
        const grupoName = col.grupo;
        let span = 0;
        const startIdx = i;
        while (i < columnas.length && columnas[i].grupo === grupoName) {
          span++;
          i++;
        }
        row1.push({ type: 'group', grupo: grupoName, colSpan: span, index: startIdx });
      }
    }

    const row2 = columnas.filter((c) => Boolean(c.grupo));

    return { row1, row2 };
  }, [columnas, hayGrupos]);

  const filtrosActivosTotal =
    Object.values(filtrosColumnas).filter((s) => s.length > 0).length +
    (fechaInicio || fechaFin ? 1 : 0) +
    (paisFiltroRapido !== 'TODOS' ? 1 : 0) +
    (soloConReunion && !ocultarFiltroReunion ? 1 : 0);

  const handleLimpiarTodosFiltros = () => {
    setBusqueda('');
    setFechaInicio('');
    setFechaFin('');
    setFiltrosColumnas({});
    setPaisFiltroRapido('TODOS');
    setSoloConReunion(false);
  };

  const construirHojaTabla = () => {
    const excelCols: ExcelColumn<any>[] = columnas.map((col) => {
      const esBool =
        col.clave.startsWith('kpi_sla_') || col.clave.startsWith('kpi_retroalimentacion_');
      const esStatus =
        col.clave === 'estado' ||
        col.clave === 'estado_teams' ||
        col.clave === 'status' ||
        col.clave === 'horario_ingreso_tipo';
      return {
        header: col.grupo ? `${col.grupo} - ${col.etiqueta}` : col.etiqueta,
        key: col.clave,
        semantic: esBool ? 'boolean' : esStatus ? 'status' : undefined,
        value: (fila) => {
          if (col.exportValue) return col.exportValue(fila[col.clave], fila);
          if (col.clave === 'consultar') {
            const dur = Number(fila.duracion_segundos || fila.duracion || 0);
            const est = String(fila.estado || '').toUpperCase();
            const noCont = est.includes('NO CONTESTADA') || est.includes('OCUPADA') || est.includes('FALLIDA') || dur === 0;
            return noCont ? 'Sin audio (0s)' : 'Disponible';
          }
          const raw = fila[col.clave];
          if (typeof raw === 'boolean') return raw ? 'Sí' : 'No';
          return raw;
        },
      };
    });

    const paisAlcance = tieneColumnaPais ? ` de ${formatearPaisAlcance(paisFiltroRapido)}` : '';
    const tituloConAlcance = `${titulo}${paisAlcance}`;

    const nombreLimpio = tituloConAlcance
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '_')
      .replace(/^_|_$/g, '');

    return {
      nombreLimpio,
      sheet: {
        name: titulo.slice(0, 31),
        title: tituloConAlcance,
        subtitle: formatearSubtituloExportacion({
          fechaInicio,
          fechaFin,
          totalFilas: filtrados.length,
          modo: `${subtitulo}${paisAlcance}`,
          extra: busqueda.trim() ? `Búsqueda: "${busqueda.trim()}"` : undefined,
        }),
        accentHex:
          icono === 'pbx'
            ? 'DC2626'
            : icono === 'celular'
            ? '2563EB'
            : icono === 'whatsapp'
            ? '059669'
            : icono === 'teams'
            ? '7C3AED'
            : 'D97706',
        columns: excelCols,
        rows: filtrados,
      },
    };
  };

  const handleExportarExcel = async () => {
    setExportando(true);
    try {
      const { nombreLimpio, sheet } = construirHojaTabla();
      await exportarTablaAExcel(
        `${nombreLimpio}_${fechaInicio || 'inicio'}_${fechaFin || formatLocalDate()}`,
        sheet
      );
    } finally {
      setExportando(false);
    }
  };

  const handleExportarPdf = async () => {
    setExportandoPdf(true);
    try {
      const { nombreLimpio, sheet } = construirHojaTabla();
      await exportarTablaAPdf(
        `${nombreLimpio}_${fechaInicio || 'inicio'}_${fechaFin || formatLocalDate()}`,
        sheet
      );
    } finally {
      setExportandoPdf(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs dark:shadow-none">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/60">
              {renderIcono()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-wide">{titulo}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{subtitulo}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {tieneColumnaPais && (
              <div className="flex items-center bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-0.5">
                {(['TODOS', 'SV', 'GT'] as const).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPaisFiltroRapido(p)}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer ${
                      paisFiltroRapido === p
                        ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {p === 'TODOS' ? 'Todos' : p === 'SV' ? '🇸🇻 SV' : '🇬🇹 GT'}
                  </button>
                ))}
              </div>
            )}
            {onSincronizarProspektia && (
              <button
                type="button"
                onClick={onSincronizarProspektia}
                disabled={sincronizandoProspektia}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer disabled:opacity-50"
                title="Consultar ProspektIA ahora (auto-sync cada 15 min) para traer leads nuevos o fechas agendadas actualizadas"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${sincronizandoProspektia ? 'animate-spin' : ''}`} />
                <span>{sincronizandoProspektia ? 'Sincronizando ProspektIA...' : 'Sincronizar con ProspektIA'}</span>
              </button>
            )}
            {icono === 'leads' && !ocultarFiltroReunion && (
              <button
                type="button"
                onClick={() => setSoloConReunion(!soloConReunion)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                  soloConReunion
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/80 dark:text-emerald-300 dark:border-emerald-500 shadow-xs'
                    : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
                title="Alternar entre ver todos los prospectos del período o solo aquellos con fecha pactada"
              >
                <Check className={`h-3.5 w-3.5 ${soloConReunion ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-400'}`} />
                <span>{soloConReunion ? 'Solo Con Reunión Pactada (Filtro Activo)' : 'Ver Todos los Prospectos del Período'}</span>
              </button>
            )}
            {icono === 'teams' && (
              <button
                type="button"
                onClick={abrirModalTeamsNuevo}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow-xs transition-all cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Registrar Reunión Teams</span>
              </button>
            )}
            {(icono === 'pbx' || icono === 'celular') && onGuardarLlamadaManual && (
              <button
                type="button"
                onClick={abrirModalLlamadaManual}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>{icono === 'pbx' ? 'Registrar Llamada PBX' : 'Registrar Llamada Celular'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleExportarExcel}
              disabled={exportando || filtrados.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer disabled:opacity-50"
              title="Descargar los registros filtrados en Excel (.xlsx)"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{exportando ? 'Exportando...' : 'Descargar Excel'}</span>
            </button>
            <button
              type="button"
              onClick={handleExportarPdf}
              disabled={exportandoPdf || filtrados.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs shadow-xs transition-all cursor-pointer disabled:opacity-50"
              title="Descargar los registros filtrados en PDF"
            >
              <FileText className="h-3.5 w-3.5" />
              <span>{exportandoPdf ? 'PDF...' : 'Descargar PDF'}</span>
            </button>
            <div className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-mono tabular-nums text-slate-700 dark:text-slate-300">
              {filtrados.length} / {datos.length} registros
            </div>
            {filtrosActivosTotal > 0 && (
              <button
                type="button"
                onClick={handleLimpiarTodosFiltros}
                className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 dark:bg-rose-950/60 dark:border-rose-800 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900 cursor-pointer"
              >
                <X className="h-3 w-3" /> Limpiar ({filtrosActivosTotal})
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Controles de Filtros: Rango de Fechas & Buscador Dinámico */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Filtro de Rango de Fechas */}
        <DateRangeFilter
          fechaInicio={fechaInicio}
          fechaFin={fechaFin}
          onChangeInicio={setFechaInicio}
          onChangeFin={setFechaFin}
          onLimpiar={() => {
            setFechaInicio('');
            setFechaFin('');
          }}
          label="Filtrar Fecha"
        />

        {/* Buscador General */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar en todos los campos..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-rose-500 shadow-xs"
          />
        </div>
      </div>

      {/* Aviso contextual de rango de fecha activo */}
      {(fechaInicio || fechaFin) && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs px-3.5 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-700 dark:text-slate-300 shadow-xs tabular-nums">
          <span className="flex items-center gap-1.5">
            <Calendar className="h-3.5 w-3.5 text-amber-500 shrink-0" />
            Filtro de fecha activo: <strong className="text-slate-900 dark:text-white font-mono">{fechaInicio || 'Inicio'}</strong> al <strong className="text-slate-900 dark:text-white font-mono">{fechaFin || 'Hoy'}</strong> ({filtrados.length} de {datos.length} registros).
          </span>
          <button
            type="button"
            onClick={() => {
              setFechaInicio('');
              setFechaFin('');
            }}
            className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
          >
            Quitar filtro y ver todos ({datos.length})
          </button>
        </div>
      )}

      {/* Tabla de Datos con Filtros en Cada Columna */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs dark:shadow-none">
        <div className="overflow-x-auto max-h-[650px]">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300 tabular-nums">
            <thead className="bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 uppercase font-bold sticky top-0 z-20 border-b border-slate-200 dark:border-slate-800">
              {hayGrupos ? (
                <>
                  {/* Fila 1: Grupos superiores y columnas sin grupo con rowSpan=2 */}
                  <tr className="border-b border-slate-200 dark:border-slate-800/80">
                    {headerEstructura.row1.map((item) => {
                      if (item.type === 'group') {
                        const esRetro = item.grupo.includes('RETROALIMENTACION');
                        return (
                          <th
                            key={item.grupo + item.index}
                            colSpan={item.colSpan}
                            className={`py-2 px-3 text-center text-[11px] font-extrabold tracking-wider uppercase border-l border-r ${
                              esRetro
                                ? 'bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800/50'
                                : 'bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800/50'
                            }`}
                          >
                            {item.grupo}
                          </th>
                        );
                      }
                      const col = item.col;
                      const idx = item.index;
                      return (
                        <th
                          key={col.clave}
                          rowSpan={2}
                          className="py-3 px-4 whitespace-nowrap align-bottom border-b border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950"
                        >
                          <ColumnFilterDropdown
                            titulo={col.etiqueta}
                            clave={col.clave}
                            valoresUnicos={valoresUnicosPorColumna[col.clave] || []}
                            seleccionados={filtrosColumnas[col.clave] || []}
                            onCambiarSeleccion={handleCambiarFiltroColumna}
                            alineacion={idx > columnas.length - 3 ? 'right' : 'left'}
                          />
                        </th>
                      );
                    })}
                  </tr>
                  {/* Fila 2: Sub-columnas correspondientes a los grupos */}
                  <tr>
                    {headerEstructura.row2.map((col) => (
                      <th
                        key={col.clave}
                        className="py-2 px-3 whitespace-nowrap text-center border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60"
                      >
                        <ColumnFilterDropdown
                          titulo={col.etiqueta}
                          clave={col.clave}
                          valoresUnicos={valoresUnicosPorColumna[col.clave] || []}
                          seleccionados={filtrosColumnas[col.clave] || []}
                          onCambiarSeleccion={handleCambiarFiltroColumna}
                          alineacion="left"
                        />
                      </th>
                    ))}
                  </tr>
                </>
              ) : (
                <tr>
                  {columnas.map((col, idx) => (
                    <th key={col.clave} className="py-3 px-4 whitespace-nowrap">
                      <ColumnFilterDropdown
                        titulo={col.etiqueta}
                        clave={col.clave}
                        valoresUnicos={valoresUnicosPorColumna[col.clave] || []}
                        seleccionados={filtrosColumnas[col.clave] || []}
                        onCambiarSeleccion={handleCambiarFiltroColumna}
                        alineacion={idx > columnas.length - 3 ? 'right' : 'left'}
                      />
                    </th>
                  ))}
                  {icono === 'teams' && (
                    <th className="py-3 px-4 text-right whitespace-nowrap uppercase text-[11px] font-bold text-slate-400">
                      Acciones
                    </th>
                  )}
                </tr>
              )}
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/80 font-mono">
              {filtrados.length === 0 ? (
                <tr>
                  <td colSpan={columnas.length + (icono === 'teams' ? 1 : 0)} className="py-12 px-6 text-center">
                    <div className="max-w-md mx-auto space-y-3 font-sans">
                      <div className="inline-flex p-3 rounded-full bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 mb-1">
                        <AlertCircle className="h-6 w-6 text-amber-500" />
                      </div>
                      <p className="text-sm font-semibold text-slate-900 dark:text-white">
                        No se encontraron registros en el rango seleccionado {fechaInicio && fechaFin ? `(${fechaInicio} al ${fechaFin})` : ''}
                      </p>
                      {icono === 'leads' ? (
                        <div className="text-xs text-slate-700 dark:text-slate-300 space-y-1.5 bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-left">
                          <p className="font-semibold text-slate-900 dark:text-white">Estado de las fuentes de datos:</p>
                          <p>
                            • <strong className="text-emerald-600 dark:text-emerald-400">Telefonía (PBX y Celular):</strong> Registros sincronizados en tiempo real hasta hoy ({getMesActualInfo().hoy}).
                          </p>
                          <p>
                            • <strong className="text-cyan-600 dark:text-cyan-400">Leads (Prospektia API):</strong> Sin registros coincidentes dentro del filtro de fecha actual ({datos.length} leads totales en histórico).
                          </p>
                        </div>
                      ) : (
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          No hay eventos registrados en este período específico. Puedes alternar rápidamente con los siguientes accesos directos:
                        </p>
                      )}
                      <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            const ant = getMesAnteriorInfo();
                            setFechaInicio(ant.inicioMes);
                            setFechaFin(ant.finMes);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 dark:bg-indigo-950/80 dark:border-indigo-700/80 dark:text-indigo-300 dark:hover:bg-indigo-900 text-xs font-medium cursor-pointer transition-colors shadow-xs"
                        >
                          Ver Mes Anterior ({getMesAnteriorInfo().nombreMes})
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            const act = getMesActualInfo();
                            setFechaInicio(act.inicioMes);
                            setFechaFin(act.hoy);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/80 dark:border-emerald-700/80 dark:text-emerald-300 dark:hover:bg-emerald-900 text-xs font-medium cursor-pointer transition-colors shadow-xs"
                        >
                          Mes Actual (Al día)
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setFechaInicio('');
                            setFechaFin('');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 border border-slate-300 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700 text-xs font-medium cursor-pointer transition-colors shadow-xs"
                        >
                          Ver Todos ({datos.length})
                        </button>
                      </div>
                    </div>
                  </td>
                </tr>
              ) : (
                filasPaginadas.map((fila, i) => (
                  <tr key={fila.id || fila.uniqueid || i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    {columnas.map((col) => (
                      <td key={col.clave} className="py-2.5 px-4 whitespace-nowrap text-slate-800 dark:text-slate-200">
                        {col.render
                          ? col.render(fila[col.clave], fila)
                          : fila[col.clave] !== undefined && fila[col.clave] !== null
                          ? String(fila[col.clave])
                          : <span className="text-slate-400 dark:text-slate-600 font-sans">-</span>}
                      </td>
                    ))}
                    {icono === 'teams' && (
                      <td className="py-2.5 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => abrirModalTeamsEditar(fila)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-purple-50 border border-purple-200 text-purple-700 hover:bg-purple-100 dark:bg-purple-950/80 dark:border-purple-700/80 dark:text-purple-300 dark:hover:bg-purple-900 text-xs font-sans font-medium transition-colors cursor-pointer shadow-xs"
                        >
                          <Edit className="h-3 w-3" />
                          <span>{fila.evidencia_url ? 'Editar' : 'Ingresar Datos'}</span>
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Barra de Paginación Rápida */}
        {filtrados.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-200 dark:border-slate-800 text-xs">
            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
              <span>
                Mostrando <strong className="text-slate-900 dark:text-white font-mono">{(paginaActual - 1) * filasPorPagina + 1}</strong> - <strong className="text-slate-900 dark:text-white font-mono">{Math.min(paginaActual * filasPorPagina, filtrados.length)}</strong> de <strong className="text-slate-900 dark:text-white font-mono">{filtrados.length}</strong> registros
              </span>
              {totalPaginas > 1 && (
                <span className="text-slate-400 dark:text-slate-500">• Página {paginaActual} de {totalPaginas}</span>
              )}
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400">
                <span>Por página:</span>
                <select
                  value={filasPorPagina}
                  onChange={(e) => {
                    setFilasPorPagina(Number(e.target.value));
                    setPaginaActual(1);
                  }}
                  className="bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-red-500 shadow-xs"
                >
                  <option value={50}>50</option>
                  <option value={100}>100</option>
                  <option value={250}>250</option>
                  <option value={500}>500</option>
                </select>
              </div>

              {totalPaginas > 1 && (
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={paginaActual === 1}
                    onClick={() => setPaginaActual(1)}
                    className="px-2 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed text-xs transition-colors shadow-xs"
                    title="Primera página"
                  >
                    ««
                  </button>
                  <button
                    type="button"
                    disabled={paginaActual === 1}
                    onClick={() => setPaginaActual((p) => Math.max(1, p - 1))}
                    className="px-2.5 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed text-xs transition-colors shadow-xs"
                    title="Página anterior"
                  >
                    « Anterior
                  </button>

                  <div className="px-2 py-1 font-mono font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded shadow-xs">
                    {paginaActual} / {totalPaginas}
                  </div>

                  <button
                    type="button"
                    disabled={paginaActual === totalPaginas}
                    onClick={() => setPaginaActual((p) => Math.min(totalPaginas, p + 1))}
                    className="px-2.5 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed text-xs transition-colors shadow-xs"
                    title="Página siguiente"
                  >
                    Siguiente »
                  </button>
                  <button
                    type="button"
                    disabled={paginaActual === totalPaginas}
                    onClick={() => setPaginaActual(totalPaginas)}
                    className="px-2 py-1 rounded bg-slate-200 hover:bg-slate-300 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 disabled:opacity-30 disabled:cursor-not-allowed text-xs transition-colors shadow-xs"
                    title="Última página"
                  >
                    »»
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Modal para Ingresar / Editar Datos de Reunión Teams */}
      {modalTeamsAbierto && editingTeamsItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/75 backdrop-blur-sm">
          <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 text-purple-600 dark:bg-purple-950/80 dark:border-purple-700/80 dark:text-purple-400">
                  <Users className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {editingTeamsItem.id ? 'Editar Datos de Reunión Teams' : 'Registrar Nueva Reunión Teams'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Evidencia y resultado para el cruce de leads virtuales
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalTeamsAbierto(false)}
                className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleGuardarTeamsSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Código Lead / Prospecto</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: LD651"
                    value={editingTeamsItem.codigo_prospecto}
                    onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, codigo_prospecto: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-mono focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">País</label>
                  <select
                    value={editingTeamsItem.pais || 'SV'}
                    onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, pais: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="SV">🇸🇻 El Salvador (SV)</option>
                    <option value="GT">🇬🇹 Guatemala (GT)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Nombre del Cliente / Prospecto</label>
                <input
                  type="text"
                  placeholder="Nombre completo del cliente"
                  value={editingTeamsItem.cliente}
                  onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, cliente: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Ejecutivo Asignado (Catálogo)</label>
                <select
                  value={editingTeamsItem.ejecutivo}
                  onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, ejecutivo: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-purple-500"
                >
                  {catalogo.length > 0 ? (
                    catalogo.map((cat: any) => (
                      <option key={cat.id || cat.usuario} value={cat.nombre_ejecutivo}>
                        {cat.nombre_ejecutivo} ({cat.pais === 'GT' ? '🇬🇹 GT' : '🇸🇻 SV'} - Ext {cat.extension || 'N/A'})
                      </option>
                    ))
                  ) : (
                    <option value={editingTeamsItem.ejecutivo || 'Asesor'}>
                      {editingTeamsItem.ejecutivo || 'Asesor'}
                    </option>
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Fecha de la Reunión</label>
                  <input
                    type="date"
                    required
                    value={editingTeamsItem.fecha_reunion}
                    onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, fecha_reunion: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Hora de la Reunión</label>
                  <input
                    type="time"
                    required
                    value={editingTeamsItem.hora_reunion}
                    onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, hora_reunion: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Estado de la Reunión Teams</label>
                <select
                  value={editingTeamsItem.estado_teams}
                  onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, estado_teams: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-medium focus:outline-none focus:border-purple-500"
                >
                  <option value="Si se hizo y tiene evidencia">✅ Sí se hizo y tiene evidencia</option>
                  <option value="Si se hizo sin evidencia">⚠️ Sí se hizo pero sin evidencia grabada</option>
                  <option value="No se realizó / Prospecto no asistió">❌ No se realizó / Prospecto no asistió</option>
                  <option value="Reprogramada">🔄 Reprogramada para otra fecha</option>
                  <option value="Pendiente de realizar">⏳ Pendiente de realizar</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">
                  Enlace de Evidencia (Teams Recap / Grabación OneDrive / SharePoint)
                </label>
                <input
                  type="url"
                  placeholder="https://teams.microsoft.com/l/meetingrecap?..."
                  value={editingTeamsItem.evidencia_url}
                  onChange={(e) => setEditingTeamsItem({ ...editingTeamsItem, evidencia_url: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-purple-500 font-mono text-[11px]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalTeamsAbierto(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={guardandoTeams}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold transition-all disabled:opacity-50 cursor-pointer shadow-sm"
                >
                  {guardandoTeams ? (
                    <span>Guardando...</span>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      <span>Guardar Registro Teams</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Registrar Llamada Manual (PBX y Celular) */}
      {modalLlamadaManualAbierto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 dark:bg-black/80 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-rose-300 dark:border-rose-500/40 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-50 text-rose-600 border border-rose-200 dark:bg-rose-500/20 dark:text-rose-400 dark:border-rose-500/30">
                  {icono === 'pbx' ? <PhoneCall className="h-5 w-5" /> : <Smartphone className="h-5 w-5" />}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Registrar Llamada Manual {icono === 'pbx' ? 'PBX' : 'Celular'}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Se insertará en Supabase (<code className="text-rose-600 dark:text-rose-300">{icono === 'pbx' ? 'public.llamadas_pbx' : 'public.llamadas_celular'}</code>) y se auditará en los KPIs.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setModalLlamadaManualAbierto(false)}
                className="p-1.5 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <form onSubmit={handleGuardarLlamadaManualSubmit} className="space-y-4 text-xs">
              {/* 1. SELECCIONAR CÓDIGO DE LEAD */}
              <div className="bg-slate-50 dark:bg-slate-950/80 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-rose-600 dark:text-rose-300 font-bold uppercase tracking-wider text-[11px]">
                    1. Seleccionar Código de Lead / Prospecto
                  </label>
                  <span className="text-[10px] text-slate-500">
                    {leadsDisponibles.length} leads disponibles
                  </span>
                </div>

                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Filtrar por código o nombre (ej: LD801, Carlos)..."
                    value={filtroLeadModal}
                    onChange={(e) => setFiltroLeadModal(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-rose-500 text-xs"
                  />
                </div>

                <select
                  value={formLlamadaManual.codigo_lead}
                  onChange={(e) => handleSeleccionarLead(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white font-medium focus:outline-none focus:border-rose-500 text-xs cursor-pointer"
                >
                  <option value="">-- Elige un prospecto para autocompletar --</option>
                  {leadsDisponibles
                    .filter((l) => {
                      if (!filtroLeadModal.trim()) return true;
                      const q = filtroLeadModal.toLowerCase();
                      const cod = String(l.codigo_prospecto || l.id || '').toLowerCase();
                      const nom = String(l.nombre_prospecto || l.nombre || l.cliente || '').toLowerCase();
                      const tel = String(l.telefono || l.celular || '');
                      return cod.includes(q) || nom.includes(q) || tel.includes(q);
                    })
                    .slice(0, 50)
                    .map((l) => (
                      <option key={l.id || l.codigo_prospecto} value={l.codigo_prospecto || l.id}>
                        [{l.codigo_prospecto || l.id}] {l.nombre_prospecto || l.nombre || l.cliente || 'Sin Nombre'} • Tel: {l.telefono || 'S/N'} • Asesor: {l.asesor_nombre || 'N/A'}
                      </option>
                    ))}
                </select>
              </div>

              {/* 2. DATOS DEL PROSPECTO AUTOCOMPLETADOS */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Nombre del Prospecto</label>
                  <input
                    type="text"
                    required
                    placeholder="Nombre completo"
                    value={formLlamadaManual.prospecto_nombre}
                    onChange={(e) =>
                      setFormLlamadaManual({ ...formLlamadaManual, prospecto_nombre: e.target.value })
                    }
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Número de Teléfono / Destino</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: 50371234567"
                    value={formLlamadaManual.telefono_destino}
                    onChange={(e) =>
                      setFormLlamadaManual({ ...formLlamadaManual, telefono_destino: e.target.value })
                    }
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                </div>
              </div>

              {/* 3. ASESOR / EJECUTIVO */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Ejecutivo / Closer</label>
                  <select
                    value={formLlamadaManual.ejecutivo}
                    onChange={(e) => handleSeleccionarEjecutivo(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-medium"
                  >
                    {catalogo.length > 0 ? (
                      catalogo.map((cat: any) => (
                        <option key={cat.id || cat.usuario} value={cat.nombre_ejecutivo}>
                          {cat.nombre_ejecutivo} ({cat.pais === 'GT' ? '🇬🇹 GT' : '🇸🇻 SV'} - Ext {cat.extension || 'N/A'})
                        </option>
                      ))
                    ) : (
                      <option value={formLlamadaManual.ejecutivo || 'LCANAS'}>
                        {formLlamadaManual.ejecutivo || 'LCANAS'}
                      </option>
                    )}
                  </select>
                </div>
                {icono === 'pbx' ? (
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Extensión PBX</label>
                    <input
                      type="text"
                      placeholder="Ej: 4031"
                      value={formLlamadaManual.extension}
                      onChange={(e) =>
                        setFormLlamadaManual({ ...formLlamadaManual, extension: e.target.value })
                      }
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-mono"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Línea Celular</label>
                    <input
                      type="text"
                      readOnly
                      value="Manual (Línea Corporativa)"
                      className="w-full bg-slate-100 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 text-slate-500 dark:text-slate-400 font-medium"
                    />
                  </div>
                )}
              </div>

              {/* 4. FECHA Y HORA DE LA LLAMADA */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-950/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Fecha de la Llamada</label>
                  <input
                    type="date"
                    required
                    value={formLlamadaManual.fecha}
                    onChange={(e) =>
                      setFormLlamadaManual({ ...formLlamadaManual, fecha: e.target.value })
                    }
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Hora de la Llamada</label>
                  <input
                    type="time"
                    step="1"
                    required
                    value={formLlamadaManual.hora}
                    onChange={(e) =>
                      setFormLlamadaManual({ ...formLlamadaManual, hora: e.target.value })
                    }
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                </div>
              </div>

              {/* 5. DURACIÓN Y ESTADO */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Duración (segundos)</label>
                  <input
                    type="number"
                    min="1"
                    value={formLlamadaManual.duracion_segundos}
                    onChange={(e) =>
                      setFormLlamadaManual({
                        ...formLlamadaManual,
                        duracion_segundos: Number(e.target.value),
                      })
                    }
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Resultado de la Llamada</label>
                  <select
                    value={formLlamadaManual.estado}
                    onChange={(e) =>
                      setFormLlamadaManual({ ...formLlamadaManual, estado: e.target.value })
                    }
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-3 py-2 text-slate-900 dark:text-white focus:outline-none focus:border-rose-500 font-medium"
                  >
                    <option value="CONTESTADA">✅ CONTESTADA</option>
                    <option value="NO CONTESTADA">❌ NO CONTESTADA</option>
                    <option value="BUSY">⏳ OCUPADO</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setModalLlamadaManualAbierto(false)}
                  className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300 font-medium transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={guardandoLlamadaManual}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold transition-all disabled:opacity-50 cursor-pointer shadow-sm"
                >
                  {guardandoLlamadaManual ? (
                    <span>Guardando en Supabase...</span>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      <span>Guardar Llamada y Auditar</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
